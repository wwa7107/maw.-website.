"use client";

import Link from "next/link";
import { PageHeader } from "@/components/page-header";
import { CTASection } from "@/components/cta-section";
import { useLanguage } from "@/components/providers/language-provider";
import { CheckCircle2, Star } from "lucide-react";

export default function PricingPage() {
  const { dict } = useLanguage();

  return (
    <>
      <PageHeader eyebrow={dict.nav.pricing} title={dict.pricing.title} subtitle={dict.pricing.subtitle} />

      <section className="mx-auto max-w-7xl px-5 py-20 lg:px-8">
        <div className="grid gap-8 lg:grid-cols-3">
          {dict.pricing.tiers.map((tier) => (
            <div
              key={tier.name}
              className={`relative flex flex-col rounded-3xl border p-8 ${
                tier.highlighted
                  ? "border-gold-400 bg-navy-800 text-cloud shadow-gold lg:-translate-y-3"
                  : "border-navy-100 bg-white dark:border-navy-700 dark:bg-navy-800"
              }`}
            >
              {tier.highlighted && (
                <span className="absolute -top-3.5 left-1/2 flex -translate-x-1/2 items-center gap-1 rounded-full bg-gold-500 px-4 py-1 text-xs font-semibold text-navy-900">
                  <Star size={12} fill="currentColor" strokeWidth={0} />
                  {dict.pricing.currency === "SAR" ? "Most Popular" : "الأكثر طلبًا"}
                </span>
              )}
              <h3
                className={`font-display text-xl font-semibold ${
                  tier.highlighted ? "text-cloud" : "text-navy-800 dark:text-cloud"
                }`}
              >
                {tier.name}
              </h3>
              <p className={`mt-2 text-sm ${tier.highlighted ? "text-navy-200" : "text-slate-soft dark:text-navy-300"}`}>
                {tier.desc}
              </p>
              <div className="mt-6 flex items-baseline gap-1.5">
                <span className={`font-display text-4xl font-bold ${tier.highlighted ? "text-gold-300" : "text-navy-800 dark:text-gold-300"}`}>
                  {tier.price}
                </span>
                <span className={`text-sm font-medium ${tier.highlighted ? "text-navy-300" : "text-slate-soft dark:text-navy-400"}`}>
                  {dict.pricing.currency} {tier.unit}
                </span>
              </div>
              <ul className="mt-7 flex-1 space-y-3">
                {tier.features.map((f) => (
                  <li
                    key={f}
                    className={`flex items-start gap-2 text-sm ${
                      tier.highlighted ? "text-navy-100" : "text-navy-700 dark:text-navy-200"
                    }`}
                  >
                    <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-gold-400" />
                    {f}
                  </li>
                ))}
              </ul>
              <Link
                href="/contact"
                className={`mt-8 rounded-full px-6 py-3 text-center text-sm font-semibold transition ${
                  tier.highlighted
                    ? "bg-gold-500 text-navy-900 hover:bg-gold-400"
                    : "bg-navy-800 text-cloud hover:bg-royal-600"
                }`}
              >
                {dict.common.getQuote}
              </Link>
            </div>
          ))}
        </div>

        <p className="mx-auto mt-8 max-w-2xl text-center text-xs text-slate-soft dark:text-navy-400">
          {dict.pricing.note}
        </p>

        <div className="mx-auto mt-16 max-w-3xl">
          <h3 className="text-center font-display text-2xl font-semibold text-navy-800 dark:text-cloud">
            {dict.pricing.addOnsTitle}
          </h3>
          <div className="mt-8 divide-y divide-navy-100 overflow-hidden rounded-2xl border border-navy-100 dark:divide-navy-700 dark:border-navy-700">
            {dict.pricing.addOns.map((addon) => (
              <div
                key={addon.name}
                className="flex items-center justify-between bg-white px-6 py-4 text-sm dark:bg-navy-800"
              >
                <span className="font-medium text-navy-700 dark:text-navy-100">{addon.name}</span>
                <span className="font-display font-semibold text-gold-600">
                  {addon.price} {addon.price.includes("%") ? "" : dict.pricing.currency}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CTASection />
    </>
  );
}
