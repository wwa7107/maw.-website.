"use client";

import { PageHeader } from "@/components/page-header";
import { CTASection } from "@/components/cta-section";
import { useLanguage } from "@/components/providers/language-provider";
import { MessageSquareText, FileSearch, PenTool, PackageCheck } from "lucide-react";

const icons = [MessageSquareText, FileSearch, PenTool, PackageCheck];

export default function HowItWorksPage() {
  const { dict } = useLanguage();

  return (
    <>
      <PageHeader eyebrow={dict.nav.how} title={dict.how.title} subtitle={dict.how.subtitle} />

      <section className="mx-auto max-w-4xl px-5 py-20 lg:px-8">
        <ol className="relative border-navy-200 rtl:border-r ltr:border-l ltr:pl-10 rtl:pr-10 dark:border-navy-700">
          {dict.how.steps.map((step, i) => {
            const Icon = icons[i];
            return (
              <li key={step.title} className="relative pb-14 last:pb-0">
                <span className="absolute top-0 flex h-11 w-11 items-center justify-center rounded-full bg-navy-800 text-gold-300 shadow-seal ltr:-left-[3.35rem] rtl:-right-[3.35rem]">
                  <Icon size={18} />
                </span>
                <div className="flex items-baseline gap-3">
                  <span className="font-display text-sm font-bold text-gold-500">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <h3 className="font-display text-xl font-semibold text-navy-800 dark:text-cloud">
                    {step.title}
                  </h3>
                </div>
                <p className="mt-2 max-w-xl leading-relaxed text-slate-soft dark:text-navy-300">
                  {step.desc}
                </p>
              </li>
            );
          })}
        </ol>
      </section>

      <CTASection />
    </>
  );
}
