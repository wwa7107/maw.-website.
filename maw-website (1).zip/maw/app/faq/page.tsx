"use client";

import { PageHeader } from "@/components/page-header";
import { CTASection } from "@/components/cta-section";
import { FAQAccordion } from "@/components/faq-accordion";
import { useLanguage } from "@/components/providers/language-provider";

export default function FAQPage() {
  const { dict } = useLanguage();

  return (
    <>
      <PageHeader eyebrow={dict.nav.faq} title={dict.faq.title} subtitle={dict.faq.subtitle} />
      <section className="mx-auto max-w-3xl px-5 py-20 lg:px-8">
        <FAQAccordion items={[...dict.faq.items]} />
      </section>
      <CTASection />
    </>
  );
}
