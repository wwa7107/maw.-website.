import { Hero } from "@/components/home/hero";
import { Stats } from "@/components/home/stats";
import { ServicesPreview } from "@/components/home/services-preview";
import { WhyChoose } from "@/components/home/why-choose";
import { Testimonials } from "@/components/testimonials";
import { CTASection } from "@/components/cta-section";

export default function HomePage() {
  return (
    <>
      <Hero />
      <Stats />
      <ServicesPreview />
      <WhyChoose />
      <Testimonials />
      <CTASection />
    </>
  );
}
