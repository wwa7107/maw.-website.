"use client";

import { PageHeader } from "@/components/page-header";
import { CTASection } from "@/components/cta-section";
import { useLanguage } from "@/components/providers/language-provider";
import { ShieldCheck, Target, Lock, Sparkles, UserRound } from "lucide-react";
import { Seal } from "@/components/ui/seal";

const valueIcons = [ShieldCheck, Target, Lock, Sparkles];

export default function AboutPage() {
  const { dict } = useLanguage();

  return (
    <>
      <PageHeader eyebrow={dict.nav.about} title={dict.about.title} subtitle={dict.about.subtitle} />

      <section className="mx-auto max-w-5xl px-5 py-20 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-[1fr_1fr] lg:items-center">
          <div>
            <h2 className="font-display text-2xl font-semibold text-navy-800 dark:text-cloud">
              {dict.about.storyTitle}
            </h2>
            <p className="mt-4 leading-relaxed text-slate-soft dark:text-navy-300">{dict.about.story}</p>
          </div>
          <div className="flex justify-center">
            <div className="diploma-border flex w-full max-w-sm flex-col items-center gap-4 rounded-3xl bg-white p-10 text-center dark:bg-navy-800">
              <Seal size={88} />
              <p className="font-display text-lg font-semibold text-navy-800 dark:text-cloud">
                {dict.about.missionTitle}
              </p>
              <p className="text-sm leading-relaxed text-slate-soft dark:text-navy-300">
                {dict.about.mission}
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-navy-50 dark:bg-navy-800/40">
        <div className="mx-auto max-w-7xl px-5 py-20 lg:px-8">
          <h2 className="text-center font-display text-3xl font-semibold text-navy-800 dark:text-cloud">
            {dict.about.valuesTitle}
          </h2>
          <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {dict.about.values.map((v, i) => {
              const Icon = valueIcons[i];
              return (
                <div key={v.title} className="rounded-2xl bg-white p-6 text-center shadow-sm dark:bg-navy-900">
                  <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-navy-800 text-gold-300">
                    <Icon size={20} />
                  </div>
                  <h3 className="font-display text-base font-semibold text-navy-800 dark:text-cloud">
                    {v.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-slate-soft dark:text-navy-300">
                    {v.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-5 py-20 lg:px-8">
        <h2 className="text-center font-display text-3xl font-semibold text-navy-800 dark:text-cloud">
          {dict.about.teamTitle}
        </h2>
        <div className="mt-12 grid gap-6 sm:grid-cols-3">
          {dict.about.team.map((member) => (
            <div
              key={member.name}
              className="flex flex-col items-center rounded-2xl border border-navy-100 p-8 text-center dark:border-navy-700"
            >
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-navy-100 text-navy-700 dark:bg-navy-700 dark:text-navy-100">
                <UserRound size={28} />
              </div>
              <p className="font-display text-base font-semibold text-navy-800 dark:text-cloud">
                {member.name}
              </p>
              <p className="mt-1 text-sm text-slate-soft dark:text-navy-300">{member.role}</p>
            </div>
          ))}
        </div>
      </section>

      <CTASection />
    </>
  );
}
