"use client";

import { PageHeader } from "@/components/page-header";
import { ContactForm } from "@/components/contact-form";
import { useLanguage } from "@/components/providers/language-provider";
import { MessageCircle, Mail, Clock, MapPin } from "lucide-react";
import { SITE } from "@/lib/site-data";

export default function ContactPage() {
  const { dict } = useLanguage();

  const infoItems = [
    { icon: MessageCircle, label: dict.contact.whatsapp, value: SITE.phoneDisplay },
    { icon: Mail, label: dict.contact.email, value: SITE.email },
    { icon: Clock, label: dict.contact.hours, value: dict.contact.hoursValue },
    { icon: MapPin, label: dict.contact.location, value: dict.contact.locationValue },
  ];

  return (
    <>
      <PageHeader eyebrow={dict.nav.contact} title={dict.contact.title} subtitle={dict.contact.subtitle} />

      <section className="mx-auto grid max-w-6xl gap-10 px-5 py-20 lg:grid-cols-[1.2fr_0.8fr] lg:px-8">
        <div className="rounded-3xl border border-navy-100 bg-white p-8 shadow-sm dark:border-navy-700 dark:bg-navy-800">
          <ContactForm />
        </div>

        <div>
          <h3 className="font-display text-xl font-semibold text-navy-800 dark:text-cloud">
            {dict.contact.infoTitle}
          </h3>
          <div className="mt-6 space-y-6">
            {infoItems.map((item) => (
              <div key={item.label} className="flex items-start gap-4">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-navy-800 text-gold-300">
                  <item.icon size={18} />
                </div>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-slate-soft dark:text-navy-400">
                    {item.label}
                  </p>
                  <p className="mt-1 text-sm font-medium text-navy-800 dark:text-cloud">{item.value}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
