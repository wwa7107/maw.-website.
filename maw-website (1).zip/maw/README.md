# MAW — Academic Services Website

A premium, bilingual (English / Arabic RTL), dark & light mode website for **MAW (Mohammed & Wajeeh)**, built with **Next.js 14 (App Router)**, **React 18**, and **Tailwind CSS**.

## ✨ What's included

- 7 pages: Home, About Us, Services, Pricing (SAR), How It Works, FAQ, Contact Us
- Full English + Arabic content with automatic RTL layout switching
- Dark / light mode (persisted, via `next-themes`)
- Floating WhatsApp button
- Testimonials, statistics, FAQ accordion, pricing tiers, contact form
- SEO: metadata, Open Graph tags, `sitemap.xml`, `robots.txt`
- Fully responsive (mobile / tablet / desktop)
- Signature brand motif: the MAW "seal" emblem, used across hero, testimonials, and diplomas-style cards

## 🚀 Getting started

```bash
npm install
npm run dev
```

Visit `http://localhost:3000`.

## 🏗️ Build for production

```bash
npm run build
npm run start
```

## ☁️ Deploying to Vercel

1. Push this project to a GitHub repository.
2. Go to [vercel.com/new](https://vercel.com/new) and import the repository.
3. Framework preset: **Next.js** (auto-detected). No special build settings needed.
4. Click **Deploy**.

## 🔧 Before going live — replace these placeholders

| What | File | Notes |
|---|---|---|
| WhatsApp number | `lib/site-data.ts` → `SITE.whatsappNumber` | Use full international format, no `+` or spaces, e.g. `9665XXXXXXXX` |
| Email address | `lib/site-data.ts` → `SITE.email` | |
| Phone display | `lib/site-data.ts` → `SITE.phoneDisplay` | |
| Domain | `lib/site-data.ts` → `SITE.domain`, plus `app/layout.tsx`, `app/sitemap.ts`, `app/robots.ts` | Used for canonical/OG URLs |
| Contact form submission | `components/contact-form.tsx` | Currently simulates a submission client-side. Wire it to an API route, email service (e.g. Resend), or Google Sheets/CRM before launch |
| Testimonials, stats, pricing figures | `lib/site-data.ts`, `lib/dictionaries.ts` | Swap in real client feedback and your actual current pricing |
| Team names / photos | `lib/dictionaries.ts` (`about.team`) | Add real photos in `public/images` and update `app/about/page.tsx` to use `next/image` |
| Favicon | `app/icon.svg` | Replace with a refined vector version of your logo if desired |

## 📁 Folder structure

```
app/                    → routes (App Router), one folder per page
  layout.tsx            → root layout, fonts, providers, header/footer
  page.tsx               → homepage
  about/ services/ pricing/ how-it-works/ faq/ contact/
  sitemap.ts robots.ts   → SEO
components/
  home/                  → homepage-only sections (hero, stats, etc.)
  providers/             → theme + language React context providers
  ui/                     → small shared UI atoms (seal emblem, icons)
  header.tsx footer.tsx whatsapp-button.tsx contact-form.tsx
  faq-accordion.tsx testimonials.tsx cta-section.tsx page-header.tsx
lib/
  dictionaries.ts        → all English + Arabic copy, in one place
  site-data.ts           → contact info, nav routes, testimonials data
```

## 🌍 Language & theme system

- Language state lives in `components/providers/language-provider.tsx`. Toggling switches `document.dir`/`lang` and persists to `localStorage`.
- All visible copy is pulled from `lib/dictionaries.ts` — edit the `en` and `ar` objects there to change any text on the site.
- Theme (dark/light) uses `next-themes`, toggled from the header.

## 🎨 Design system

Brand tokens live in `tailwind.config.ts`:
- `navy` — primary dark/ink color
- `royal` — interactive blue accent
- `gold` — premium accent or "seal" color
- `cloud` — light background

Fonts (loaded via Google Fonts `<link>` in `app/layout.tsx`): **Playfair Display** (English display), **Amiri** (Arabic display), **Inter** (English body), **Tajawal** (Arabic body).
